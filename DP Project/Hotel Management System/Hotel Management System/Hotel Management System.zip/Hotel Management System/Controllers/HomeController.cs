﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Security;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Hotel_Management_System.Models;
using System.Net;
using System.Security.Cryptography.Xml;

namespace Hotel_Management_System.Controllers
{
    public class HomeController : Controller
    {
        public HomeController()
        {
            RoomFactory SRF, TRF, DRF, QRF, KRF;
            ROOMS SRoom, TRoom, DRoom, QRoom, KRoom;

            ViewData["RoomDescriptionHeading"] = ROOMS.RoomsDescriptionHeading();

            SRF = new SingleRoomFactory();
            SRoom = SRF.RequestRoom("Single-Room");
            ViewData["SingleRoomPrice"] = SRoom.RoomPriceTag();
            ViewData["SingleRoomDescription"] = SRoom.RoomDescription();

            TRF = new TwinRoomFactory();
            TRoom = TRF.RequestRoom("Twin-Room");
            ViewData["TwinRoomPrice"] = TRoom.RoomPriceTag();
            ViewData["TwinRoomDescription"] = TRoom.RoomDescription();

            DRF = new DoubleRoomFactory();
            DRoom = DRF.RequestRoom("Double-Room");
            ViewData["DoubleRoomPrice"] = DRoom.RoomPriceTag();
            ViewData["DoubleRoomDescription"] = DRoom.RoomDescription();

            QRF = new QueenRoomFactory();
            QRoom = QRF.RequestRoom("Queen-Room");
            ViewData["QueenRoomPrice"] = QRoom.RoomPriceTag();
            ViewData["QueenRoomDescription"] = QRoom.RoomDescription();

            KRF = new KingRoomFactory();
            KRoom = KRF.RequestRoom("King-Room");
            ViewData["KingRoomPrice"] = KRoom.RoomPriceTag();
            ViewData["KingRoomDescription"] = KRoom.RoomDescription();
        }
        public ActionResult Index()
        {
            HomeControllerPagesCookiesDestroyer();
            if (GlobalVariables.SurfingMode != false)
            {
                return View();
            }
            else
            {
                return RedirectToAction("", "Home/Login");
            }
        }

        public ActionResult Guest()
        {
            GlobalVariables.SurfingMode = true;
            HomeControllerPagesCookiesDestroyer();
            return RedirectToAction("", "Home/Index");
        }

        public ActionResult About()
        {
            HomeControllerPagesCookiesDestroyer();
            ViewBag.Message = "Here Below you will find details about us, about our Hotel!!!.";
            return View();
        }

        public ActionResult Contact()
        {
            HomeControllerPagesCookiesDestroyer();
            return View();
        }

        public ActionResult Login()
        {
            HomeControllerPagesCookiesDestroyer();
            if (GlobalVariables.SurfingMode != false)
            {
                return View();
            }
            else if(GlobalVariables.SurfingMode != true)
            {
                return View();
            }
            else
            {
                ViewData["GuestAlert"] = "<script>alert('Kindly Please Login/Signup Create your account as our Customer first then your Room Booking will Proceed!!!')</script>";
                return RedirectToAction("", "Home/Login");////Work-from-Here!!!!!
            }
        }
        [HttpPost]
        public ActionResult Login(Employee Login)
        {
            using (var HMSDB = new Hotel_Management_SystemEntities())
            {
                GlobalVariables.IsValidCustomerUser = HMSDB.Customers.Any(login => Login.Username == login.Username);
                GlobalVariables.IsValidCustomerPassword = HMSDB.Customers.Any(login => Login.Password == login.Password);
                GlobalVariables.IsValidUser = HMSDB.Employees.Any(login => Login.Username == login.Username);
                GlobalVariables.IsValidPassword = HMSDB.Employees.Any(login => Login.Password == login.Password);
                if (GlobalVariables.IsValidUser == true && GlobalVariables.IsValidPassword == true)
                {
                       var LoginCredentials = HMSDB.Employees.Where(
                                    login => Login.Username == login.Username && Login.Password == login.Password).FirstOrDefault();
                    if (LoginCredentials != null && ModelState.IsValid == true)
                    {
                        GlobalVariables.IsAdmin = LoginCredentials.Employee_Department.Contains("Admin-Owner") ||
                            LoginCredentials.Employee_Department.Contains("Manager") || LoginCredentials.Employee_Department.Contains("Co-Manager") ||
                            LoginCredentials.Employee_Department.Contains("Owner");
                        if (GlobalVariables.IsAdmin == true && GlobalVariables.IsValidUser == true && GlobalVariables.IsValidPassword == true)
                        {
                            GlobalVariables.CookieName = HttpUtility.UrlEncode(Hotel_Management_System.Controllers.CryptoEngine.Encrypt("LNCTS", Hotel_Management_System.Controllers.CryptoEngine.PPP()));
                            GlobalVariables.LoginCredentialsCookies = new HttpCookie(GlobalVariables.CookieName);
                            GlobalVariables.LoginCredentialsCookies.Values.Add(CryptoEngine.Encrypt(LoginCredentials.Username, CryptoEngine.PPP()), CryptoEngine.Encrypt(LoginCredentials.Username, CryptoEngine.PPP()));
                            GlobalVariables.LoginCredentialsCookies.Values.Add(CryptoEngine.Encrypt(LoginCredentials.Password, CryptoEngine.PPP()), CryptoEngine.Encrypt(LoginCredentials.Password, CryptoEngine.PPP()));
                            GlobalVariables.LoginCredentialsCookies.Expires = DateTime.Now.AddMinutes(1000); 
                            GlobalVariables.LoginCredentialsCookies.HttpOnly = true;
                            GlobalVariables.SurfingMode = true;
                            HttpContext.Response.Cookies.Add(GlobalVariables.LoginCredentialsCookies);
                            return RedirectToAction("Index", "EMPLOYEES_VIEW");
                        }
                        else if (GlobalVariables.IsAdmin != true && GlobalVariables.IsValidUser == true && GlobalVariables.IsValidPassword == true)
                        {
                            GlobalVariables.CookieName = HttpUtility.UrlEncode(Hotel_Management_System.Controllers.CryptoEngine.Encrypt("LNCTS", Hotel_Management_System.Controllers.CryptoEngine.PPP()));
                            GlobalVariables.LoginCredentialsCookies = new HttpCookie(GlobalVariables.CookieName);
                            GlobalVariables.LoginCredentialsCookies.Values.Add(CryptoEngine.Encrypt(LoginCredentials.Username, CryptoEngine.PPP()), CryptoEngine.Encrypt(LoginCredentials.Username, CryptoEngine.PPP()));
                            GlobalVariables.LoginCredentialsCookies.Values.Add(CryptoEngine.Encrypt(LoginCredentials.Password, CryptoEngine.PPP()), CryptoEngine.Encrypt(LoginCredentials.Password, CryptoEngine.PPP()));
                            GlobalVariables.LoginCredentialsCookies.Expires = DateTime.Now.AddMinutes(1000);
                            GlobalVariables.LoginCredentialsCookies.HttpOnly = true;
                            GlobalVariables.SurfingMode = true;
                            HttpContext.Response.Cookies.Add(GlobalVariables.LoginCredentialsCookies);
                            return RedirectToAction("Indexx", "CUSTOMERS_VIEW");
                        }
                        else
                        {
                            ViewBag.Errormsg = "Login Failed";
                            return View();
                        }
                    }
                    else
                    {
                        ViewBag.Errormsg = "Login Failed";
                        return View();
                    }
                }
                else if (GlobalVariables.IsValidCustomerUser == true && GlobalVariables.IsValidCustomerPassword == true)
                {
                    var CustomersLoginCredentials = HMSDB.Customers.Where(
                                 login => Login.Username == login.Username && Login.Password == login.Password).FirstOrDefault();
                    if (CustomersLoginCredentials != null && ModelState.IsValid == true)
                    {
                        GlobalVariables.CookieName = HttpUtility.UrlEncode(Hotel_Management_System.Controllers.CryptoEngine.Encrypt("LNCTS", Hotel_Management_System.Controllers.CryptoEngine.PPP()));
                        GlobalVariables.LoginCredentialsCookies = new HttpCookie(GlobalVariables.CookieName);
                        GlobalVariables.LoginCredentialsCookies.Values.Add(CryptoEngine.Encrypt(CustomersLoginCredentials.Username, CryptoEngine.PPP()), CryptoEngine.Encrypt(CustomersLoginCredentials.Username, CryptoEngine.PPP()));
                        GlobalVariables.LoginCredentialsCookies.Values.Add(CryptoEngine.Encrypt(CustomersLoginCredentials.Password, CryptoEngine.PPP()), CryptoEngine.Encrypt(CustomersLoginCredentials.Password, CryptoEngine.PPP()));
                        GlobalVariables.LoginCredentialsCookies.Expires = DateTime.Now.AddMinutes(1000);
                        GlobalVariables.LoginCredentialsCookies.HttpOnly = true;
                        GlobalVariables.SurfingMode = true;
                        HttpContext.Response.Cookies.Add(GlobalVariables.LoginCredentialsCookies);
                        GlobalVariables.CustomerID = CustomersLoginCredentials.Customer_ID;
                        GlobalVariables.CustomerName = CustomersLoginCredentials.Customer_First_name;
                        GlobalVariables.CustomerEmail = CustomersLoginCredentials.Customer_Email_Address;
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ViewBag.Errormsg = "Login Failed";
                        return View();
                    }
                }
                else
                {
                    ViewBag.Errormsg = "Login Failed";
                    return View();
                }
            }
        }
        public ActionResult Logout()
        {
            GlobalVariables.LoginCredentialsCookies.Expires = DateTime.Now.AddMinutes(-1);
            GlobalVariables.LoginCredentialsCookies.HttpOnly = true;
            System.Web.HttpContext.Current.Response.Cookies.Set(GlobalVariables.LoginCredentialsCookies); GlobalVariables.CookieName = null;
            GlobalVariables.IsAdmin = false; GlobalVariables.IsValidUser = false; GlobalVariables.IsValidPassword = false;
            return RedirectToAction("", "Home/Login");
        }
        public void HomeControllerPagesCookiesDestroyer()
        {
            if (GlobalVariables.LOGINAUTHENTICATION() != true)
            {
                if (System.Web.HttpContext.Current.Response.Cookies.Count != 0 || System.Web.HttpContext.Current.Request.Cookies.Count != 0)
                {
                    for (int i = 0; i < System.Web.HttpContext.Current.Request.Cookies.Count; i++)
                    {
                        HttpCookie cookies = new HttpCookie(System.Web.HttpContext.Current.Request.Cookies.GetKey(i).ToString());
                        cookies.Expires = DateTime.Now.AddMinutes(-1);
                        cookies.HttpOnly = true;
                        System.Web.HttpContext.Current.Response.Cookies.Set(cookies);
                    }
                    //GlobalVariables.GuestMode = false;
                }
            }
        }
    }
    static class CryptoEngine
    {
        public static string Encrypt(string input, string key)
        {
            byte[] inputArray = UTF8Encoding.UTF8.GetBytes(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        //public static string Decrypt(string input, string key)
        //{
        //    byte[] inputArray = Convert.FromBase64String(input);
        //    TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
        //    tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
        //    tripleDES.Mode = CipherMode.ECB;
        //    tripleDES.Padding = PaddingMode.PKCS7;
        //    ICryptoTransform cTransform = tripleDES.CreateDecryptor();
        //    byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
        //    tripleDES.Clear();
        //    return UTF8Encoding.UTF8.GetString(resultArray);
        //}
        public static string PPP()
        {
            byte[] bytes = new byte[16];
            RandomNumberGenerator rng = RandomNumberGenerator.Create();
            rng.GetBytes(bytes);
            string D = Convert.ToBase64String(bytes);
            return D;
        }
    }



    
    abstract class RoomFactory
    {
        public ROOMS RequestRoom(string Type)
        {
            ROOMS Room;
            Room = CreateRoom(Type);

            ROOMS.RoomsDescriptionHeading();
            Room.RoomType();
            Room.RoomPriceTag();
            Room.RoomDescription();

            return Room;
        }
        protected abstract ROOMS CreateRoom(string Type);
    }
    class SingleRoomFactory : RoomFactory
    {
        protected override ROOMS CreateRoom(string Type)
        {
            if (Type == "Single-Room")
            {
                return new SingleRoom();
            }
            else
            {
                return null;
            }
        }
    }
    class TwinRoomFactory : RoomFactory
    {
        protected override ROOMS CreateRoom(string Type)
        {
            if (Type == "Twin-Room")
            {
                return new TwinRoom();
            }
            else
            {
                return null;
            }
        }
    }
    class DoubleRoomFactory : RoomFactory
    {
        protected override ROOMS CreateRoom(string Type)
        {
            if (Type == "Double-Room")
            {
                return new DoubleRoom();
            }
            else
            {
                return null;
            }
        }
    }
    class QueenRoomFactory : RoomFactory
    {
        protected override ROOMS CreateRoom(string Type)
        {
            if (Type == "Queen-Room")
            {
                return new QueenRoom();
            }
            else
            {
                return null;
            }
        }
    }
    class KingRoomFactory : RoomFactory
    {
        protected override ROOMS CreateRoom(string Type)
        {
            if (Type == "King-Room")
            {
                return new KingRoom();
            }
            else
            {
                return null;
            }
        }
    }

    abstract class ROOMS
    {
        public static string RoomsDescriptionHeading()
        {
            return "FEATURED ROOMS";
        }
        public abstract string RoomType();
        public abstract string RoomPriceTag();
        public abstract int RoomPrice { get; }
        public abstract string RoomDescription();
        public List<string> Rooms_Categories { get; set; }
        public abstract int TotalCost(int IntervalofStay, int NoofRooms);
        //public abstract bool RoomReservationAvail(DateTime IDTI, DateTime IDTO, List<DateTime> DIN, List<DateTime> Dout, List<int> CR, List<string> RCC);
    }
    class SingleRoom : ROOMS
    {
        public SingleRoom()
        {
            Rooms_Categories = new List<string>();
            Rooms_Categories.Add(RoomType());
        }
        public override string RoomType()
        {
            return "Single-Room";
        }
        public override int RoomPrice
        {
            get
            {
                return 5000;
            }
        }
        public override string RoomPriceTag()
        {
            return "Single Room - (" + RoomPrice.ToString() + " Rs.)";
        }
        public override string RoomDescription()
        {
            return "Guest rooms classified as singles for instance, a smaller room, a twin bed have a single bed. " +
            "These rooms are assigned to one person or a couple. It may have one or more beds, but the size of the bed depends on the hotel. " +
            "Some single rooms have a twin bed, most will have a double, few will have a queen bed.";
        }
        public override int TotalCost(int IntervalofStay, int NoofRooms)
        {
            int TotalCost = IntervalofStay * RoomPrice;
            TotalCost *= NoofRooms;
            return TotalCost;
        }
    }
    class TwinRoom : ROOMS
    {
        public TwinRoom()
        {
            Rooms_Categories = new List<string>();
            Rooms_Categories.Add(RoomType());
        }
        public override string RoomType()
        {
            return "Twin-Room";
        }
        public override int RoomPrice
        {
            get
            {
                return 8000;
            }
        }
        public override string RoomPriceTag()
        {
            return "Twin Room - (" + RoomPrice.ToString() + " Rs.)";
        }
        public override string RoomDescription()
        {
            return "Twin room: twin rooms are assigned to two people; expect one double bed, or two twin beds " +
            "depending on the hotel. Triple room: as the name might suggest, this room is equipped for three people to stay.The room will " +
            "have a combination of either three twin beds, one double bed and a twin, or two double beds.";
        }
        public override int TotalCost(int IntervalofStay, int NoofRooms)
        {
            int TotalCost = IntervalofStay * RoomPrice;
            TotalCost *= NoofRooms;
            return TotalCost;
        }
    }
    class DoubleRoom : ROOMS
    {
        public DoubleRoom()
        {
            Rooms_Categories = new List<string>();
            Rooms_Categories.Add(RoomType());
        }
        public override string RoomType()
        {
            return "Double-Room";
        }
        public override int RoomPrice
        {
            get
            {
                return 10000;
            }
        }
        public override string RoomPriceTag()
        {
            return "Double Room - (" + RoomPrice.ToString() + " Rs.)";
        }
        public override string RoomDescription()
        {
            return "This room is equipped for Refers to a room with a double bed, typically intended for two occupants. The room will have " +
            "a combination of either three twin beds, one double bed and a twin, or two double beds. Large triple rooms vary in size and " +
            "configuration.The room is slightly larger than a traditional double room and features air conditioning(even at a Basic rate). " +
            "Triple occupancy means three people sharing a room.";
        }
        public override int TotalCost(int IntervalofStay, int NoofRooms)
        {
            int TotalCost = IntervalofStay * RoomPrice;
            TotalCost *= NoofRooms;
            return TotalCost;
        }
    }
    class QueenRoom : ROOMS
    {
        public QueenRoom()
        {
            Rooms_Categories = new List<string>();
            Rooms_Categories.Add(RoomType());
        }
        public override string RoomType()
        {
            return "Queen-Room";
        }
        public override int RoomPrice
        {
            get
            {
                return 13000;
            }
        }
        public override string RoomPriceTag()
        {
            return "Queen Room - (" + RoomPrice.ToString() + " Rs.)";
        }
        public override string RoomDescription()
        {
            return "A Queen room Refers to a room with a queen - sized bed, usually intended for two occupants. It is more likely of a " +
            "family Room. Queen Room living combines privacy with ample opportunity for interpersonal interaction with others living " +
            "in the building. Bathroom facilities are located on every floor.";
        }
        public override int TotalCost(int IntervalofStay, int NoofRooms)
        {
            int TotalCost = IntervalofStay * RoomPrice;
            TotalCost *= NoofRooms;
            return TotalCost;
        }
    }
    class KingRoom : ROOMS
    {
        public KingRoom()
        {
            Rooms_Categories = new List<string>();
            Rooms_Categories.Add(RoomType());
        }
        public override string RoomType()
        {
            return "King-Room";
        }
        public override int RoomPrice
        {
            get
            {
                return 15000;
            }
        }
        public override string RoomPriceTag()
        {
            return "King Room - (" + RoomPrice.ToString() + " Rs.)";
        }
        public override string RoomDescription()
        {
            return "A standard king bed room has one standard size king bed and a pull out sofa bed with one bathroom and " +
            "a small area with a coffee maker.It comes with a television and cable box. Approximately 300 sq ft, small pullout sofa fits 56 " +
            "standard semi pillow top king bed, large windows for sunlight, refridge, hair dryer, large white bath towels, quartz countertop in " +
            "bathroom, usual marriot room.overall compare to holiday inn king room.";
        }
        public override int TotalCost(int IntervalofStay, int NoofRooms)
        {
            int TotalCost = IntervalofStay * RoomPrice;
            TotalCost *= NoofRooms;
            return TotalCost;
        }
    }

    //public abstract Services CreateRoomServices();

    //public override Services CreateRoomServices()
    //{
    //    return new SingleRoomServices();
    //}
    //abstract class Services
    //{

    //}
    //class SingleRoomServices : Services
    //{

    //}

    //public override bool RoomReservationAvail(DateTime IDTI, DateTime IDTO, List<DateTime> DIN, List<DateTime> Dout, List<int> CR, List<string> RCC)
    //{
    //    List<int> SCR = new List<int>();
    //    List<DateTime> din = new List<DateTime>();
    //    List<DateTime> dout = new List<DateTime>();
    //    bool CRequaltoRCC = CR.Count == RCC.Count;
    //    if (CRequaltoRCC)
    //    {
    //        for (int i = 0; i < CR.Count; i++)
    //        {
    //            if (RCC[i] == "Single-Room")
    //            {
    //                SCR.Add(CR[i]);
    //                din.Add(DIN[i]);
    //                dout.Add(Dout[i]);
    //            }
    //        }
    //        if (SCR.Count < 11 && din.Count == dout.Count)
    //        {
    //            for (int i = 0; i < din.Count; i++)
    //            {
    //                if (IDTI == din[i] && IDTO == dout[i])
    //                {
    //                    return false;
    //                }
    //                else
    //                {
    //                    return true;
    //                }
    //            }
    //        }
    //        return false;
    //    }
    //    else
    //    {
    //        return false;
    //    }
    //}
}